# Adversarial Object Mesh Models from the Dexterity Network (Dex-Net)

# OVERVIEW
This folder contains 13 synthetic 3D mesh models in .OBJ format downloaded from Thingiverse.
The meshes are rescaled and transformed from the original versions.

# LICENSE
The meshes are aviailable under the Creative Commons License.
We can provide the source URL upon request.